# name : Tomer Koas, ID : 318879806
#!/bin/bash

# a function to create a new parsed pgn file.
createNewFile () {
 touch "$3/$1_$2.pgn"
 chmod 777 "$3/$1_$2.pgn"
 echo "" > "$3/$1_$2.pgn"
 echo "Saved game to $3/$1_$2.pgn" 
}
file=$1
if [ $# -ne 2 ]; then
      echo "Usage: $0 <source_pgn_file> <destination_directory>"
      exit 1
fi
test -e $file
if [ $? -eq 1 ]; then 
     echo "Error: File '$1' does not exist."
     exit 1
fi
test -d $2
if [ $? -eq 1 ]; then
   mkdir "$2"
   echo "Created directory '$2'."
fi
pattern="^\[Event .*"
    gameCounter=0
    fileName=$(basename $file .pgn)
    while read line; do
          if [[ $line =~ $pattern ]]; then
               ((gameCounter++))
               createNewFile "$fileName" "$gameCounter" "$2"
          fi
          echo "$line" >> "$2/${fileName}_${gameCounter}.pgn"
    done < $file
echo "All games have been split and saved to '$2'."
