# name : Tomer Koas, ID : 318879806
#!/bin/bash

#function to print the metadata part of the pgn, every line that starts with '['
printDetails(){
echo "Metadata from PGN file:"
grep -i "^\[.*" $1
echo
}

#a function that prints the current state the board is in
printCurrentBoard(){
echo "Move $moveCounter/$totalMoves"
    echo "  a b c d e f g h"
    for ((i=0; i<8; i++)); do
        echo -n "$((8 - i)) "
        for ((j=0; j<8; j++)); do
            echo -n "${board[$((i*8+j))]}"
        done
        echo "$((8 - i))"
    done
    echo "  a b c d e f g h"
}

#a function to reset the board back to the start of a game.
resetBoard(){
board=(
       "r " "n " "b " "q " "k " "b " "n " "r "
       "p " "p " "p " "p " "p " "p " "p " "p "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       "P " "P " "P " "P " "P " "P " "P " "P "
       "R " "N " "B " "Q " "K " "B " "N " "R "
)
}

#a function to update the board to the current move counter
updateBoard(){
resetBoard
   for ((i=0; i<$moveCounter; i++)) do
      local move=${moves[i]}
      local fromRow=$(( 8-${move:1:1} ))
      local toRow=$(( 8-${move:3:1} ))
      local fromCollumn=$( echo "${move:0:1}" | tr 'a-h' '0-7' )
      local toCollumn=$( echo "${move:2:1}" | tr 'a-h' '0-7' )
      local from=$(( $fromRow * 8 + $fromCollumn ))
      local to=$(( $toRow * 8 + $toCollumn ))
      if [ ${#move} -eq 5 ]; then #special case for promotion
         if (( $moveCounter % 2 == 0 )); then #check if its white or blacks turn
            board[$to]= "${move:4:1} "
         else 
            board[$to]= "$( echo ${move:4:1}  | tr '[:lower:]' '[:upper:]' ) " #for white adjust to capital letter
         fi
      else    #normal move
          board[$to]=${board[$from]}
      fi
      board[$from]=". "
      done
}

test -e $1 #check path
    if [ $? -eq 1 ]; then
        echo "File does not exist: $1"
        exit 1
    fi 
printDetails $1
board=(
       "r " "n " "b " "q " "k " "b " "n " "r "
       "p " "p " "p " "p " "p " "p " "p " "p "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       ". " ". " ". " ". " ". " ". " ". " ". "
       "P " "P " "P " "P " "P " "P " "P " "P "
       "R " "N " "B " "Q " "K " "B " "N " "R "
)
input=$(grep -v "^\[.*" $1 | tr '\n' ' ' | tr '\t' ' ') #save the part of the moves from the pgn
moves=($(python3 parse_moves.py "$input"))
moveCounter=0
totalMoves=${#moves[@]}
printCurrentBoard
echo "Press 'd' to move forward, 'a' to move back, 'w' to go to the start, 's' to go to the end, 'q' to quit:"
read decision
while [ "$decision" != "q" ]; do #start reading from user until he decides to close
    case $decision in
    d)if [ $moveCounter -lt $totalMoves ]; then
         ((moveCounter++))
         updateBoard
         printCurrentBoard
      else
         echo "No more moves available."
      fi ;;
    a)if [ $moveCounter -gt 0 ]; then
      ((moveCounter--))
      fi 
      updateBoard
      printCurrentBoard;;
    w)moveCounter=0
      resetBoard
      printCurrentBoard;;
    s)moveCounter=$totalMoves
      updateBoard
      printCurrentBoard;;
    *)echo "Invalid key pressed: $decision";;
    esac
    echo "Press 'd' to move forward, 'a' to move back, 'w' to go to the start, 's' to go to the end, 'q' to quit:"
    read decision
done 
echo "Exiting."
echo "End of game."
