// name : Tomer Koas, ID : 318879806
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_INPUT 100
#define HISTORY_SIZE 100
char *original_path;

void callCd(char **args){
    if (args[1] == NULL) {
        fprintf(stderr, "chdir failed: Bad address\n");
    } else {
        if (chdir(args[1]) != 0) {
            perror("chdir failed:");
        }
    }
}

void callPwd(){
    char cwd[MAX_INPUT];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("%s\n", cwd);
    } else {
        perror("getcwd failed:");
    }
}

void callHistory(char history[][MAX_INPUT], int history_count){
    for (int i = 0; i < history_count; i++) {
        printf("%s\n", history[i]);
    }
}

void addToHistory(char history[][MAX_INPUT], int *history_count, const char *command){
    if (*history_count < HISTORY_SIZE) {
        strcpy(history[*history_count], command);
        (*history_count)++;
    }
}

void restoreEnv(){
    setenv("PATH", original_path, 1);
}

void freeArgs(char** args, int arg_count){
    for (int i = 0; i < arg_count; i++) {
        free(args[i]);
    }
    free(args);
}

int main(int argc, char *argv[]) {
    char input[MAX_INPUT];
    char history[HISTORY_SIZE][MAX_INPUT];
    int history_count = 0;
    char custom_path[4096];
    original_path = getenv("PATH");

    // Initialize custom_path with the original PATH value
    strcpy(custom_path, original_path);

    // Append custom directories passed as arguments to PATH
    for (int i = 1; i < argc; i++) {
        strcat(custom_path, ":");
        strcat(custom_path, argv[i]);
    }
    
    // Update new PATH
    setenv("PATH", custom_path, 1);

    while (1) {
        printf("$ ");
        fflush(stdout);
        if (!fgets(input, MAX_INPUT, stdin)) {
            break;
        }

        // Remove newline character from input
        input[strcspn(input, "\n")] = 0;

        // Add command to history
        addToHistory(history, &history_count, input);

        // Parse the input into arguments dynamically
        int arg_count = 0;
        char **args=NULL;
        char **temp=NULL;
        char *arg = strtok(input, " ");
        while (arg != NULL) {
            temp = realloc(args, sizeof(char *) * (arg_count + 1));
            if(temp != NULL){
                args=temp;
            }else{
                freeArgs(args,arg_count);
                return 1;
            }
            args[arg_count] = malloc(strlen(arg) + 1);
            if (args[arg_count] == NULL) {
                perror("malloc failed");
                // Free previously allocated memory before returning
                freeArgs(args,arg_count);
                return 1;
            }
            strcpy(args[arg_count], arg);
            arg_count++;
            arg = strtok(NULL, " ");
        }
        temp=NULL;
        temp = realloc(args, sizeof(char *) * (arg_count + 1));
        if(temp != NULL){
            args=temp;
        }else{
            freeArgs(args,arg_count);
            return 1;
        }
        args[arg_count] = NULL;
        // Handle built-in commands
        if (strcmp(args[0], "cd") == 0) {
            callCd(args);
        } else if (strcmp(args[0], "pwd") == 0) {
            callPwd();
        } else if (strcmp(args[0], "history") == 0) {
            callHistory(history, history_count);
        } else if (strcmp(args[0], "exit") == 0) {
            freeArgs(args,arg_count);
            break;
        } else {
            // Fork and execute the command
            pid_t pid = fork();
            if (pid == 0) {
                // Child process
                if (execvp(args[0], args) == -1) {
                    perror("exec failed");
                }
                exit(1);
            } else if (pid < 0) {
                perror("fork failed");
            } else {
                // Parent process
                wait(NULL);
            }
        }
        if(history_count==HISTORY_SIZE){
            break;
        }
        if(*args!=NULL) {
            freeArgs(args,arg_count);
        }
    }
    // Restore the original PATH
    atexit(restoreEnv);
    return 0;
}

